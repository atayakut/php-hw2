<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <title>add product</title>
</head>
<body>
    <!-- Header -->
    <?php include 'header.php'; ?>

    <!-- content -->
    <div class="container">
        <h1>add product</h1>
        <!--add product form -->
        <form action="create_product.php" method="POST" enctype="multipart/form-data">
            <label for="product_name">product name:</label>
            <input type="text" id="product_name" name="product_name" required>

            <label for="product_image">product image:</label>
            <input type="file" id="product_image" name="product_image" accept="image/*" required>

            <button type="submit">add product</button>
        </form>
    </div>

    <!-- Footer -->
    <?php include 'footer.php'; ?>
</body>
</html>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <title>product details</title>
</head>
<body>
    <!-- Header -->
    <?php include 'header.php'; ?>

    <!-- content -->
    <div class="container">
        <h1>product details</h1>
        <!-- bring the product detals according to ID -->
        <div class="product-details">
            <h2>product details</h2>
            <p>description: Lorem ipsum dolor sit amet...</p>
            <p>price: 10.99 $</p>
            <!-- other product details           <img src=""C:\Users\atabe\OneDrive\Masaüstü\asdasd202106121343540.jpeg"" alt=" "C:\Users\atabe\OneDrive\Masaüstü\asdasd202106121343540.jpeg"">
            <?php if($loggedIn): ?>
                <a href="edit_product.php?id=1">Düzenle</a>
                <a href="delete_product.php?id=1">Sil</a>
            <?php endif; ?>
        </div>
    </div>

    <!-- Footer -->
    <?php include 'footer.php'; ?>
</body>
</html>
